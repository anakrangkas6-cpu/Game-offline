Scene starter dibuat dari Unity menu: Bella > Create Starter Scene.
